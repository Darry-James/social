<?php defined('ALTUMCODE') || die() ?>


    <div class="container-fluid no-gutters">
        <div class="d-flex">
            <div class="sidebar">
                <nav class="navbar flex-column sidebar-contents">
                    <div class="navbar-collapse">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-item active">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="flaticon-megaphone icons nav-icon"></span>
                                   My plan
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           <!--  <li class="nav-item active">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                             <li class="nav-item">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Package
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-payments">
                                    <span class="fa fa-fw fa fa-dollar-sign icons nav-icon"></span>
                                    Payments
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           
                           <li class="nav-item">
                                <a class="nav-link" href="logout">
                                    <span class="fa fa-fw fa fa-sign-out-alt icons nav-icon"></span>
                                    Logout
                                </a>
                            </li> -->

                            <li class="nav-item mb-0">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>
                            <ul class="nav nav-item settings-sub-nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/tutorials/">Tutorials</a>
                                </li>
                                <!-- <li class="nav-item">
                                    <a class="nav-link" href="#">Support</a>
                                </li> -->
                                <li class="nav-item">
                                    <a class="nav-link" href="account-payments">Billing</a>
                                </li>
                                
                                

                            </ul>
                            
                            <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/bonuses/">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Bonuses
                                     </a>
                                </li>
                            

                            <li class="nav-item">
                                <a class="nav-link" href="https://patrienickhelp.freshdesk.com/support/home">
                                    <span class="flaticon-information icons nav-icon"></span>
                                    Knowledge Base
                                </a>
                            </li>


                        </ul>


                    </div>
               <div>
                        <a class="btn" href="logout">
                            <img class="logout" src="<?= SITE_URL . ASSETS_URL_PATH . 'logout.svg' ?>" alt="log out">
                        </a>
                    </div>
                </nav>
            </div>
            <div class="container-fluid flex-grow-1">
                <div class="d-flex justify-content-between header-wrap">
                    <div class="user-greeting-wrap">
                        <div class="user-greeting">
                            <!-- Welcome, -->
                            <span class="user-name"><!-- <?= $this->user->name ?> --></span>
                        </div>
                        <div class="more-info">
                        <h6><!-- Getting started  --></h6><br> 


                        </div>

                   
                        

                        </div>




                    <div class="d-flex section-right">
                        <div class="guide-btn-wrap">
                            <a name="btn-help-desk" id="btn-help-desk" class="btn btn-help-desk" href="https://patrienickhelp.freshdesk.com/support/tickets/new"
                                role="button">HELP DESK</a>
                            <a name="btn-tour-guide" id="btn-tour-guide" class="btn btn-tour-guide" href="https://engagrmate.com/tutorials/"
                                role="button">TOUR GUIDE</a>
                        </div>
                        <div class="notification-wrap">
                            <span class="flaticon-music-and-multimedia icons notification-icon"></span>
                        </div>
                        <div class="user-icon">
                            <a href="account">
                                <span class="flaticon-user icons user-icon-default">

                                </span>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="container-fluid">
                   <!-- <div class="d-flex user-links-box">
                        <div class="d-flex user-html-box flex-grow-1">
                            <div class="form-group mb-0">
                                
                         <p>
                    <span class="badge badge-success"><?= sprintf($this->language->account->package->header, $this->user->package->name) ?></span>

                    <?php if($this->user->package_id != 'free'): ?>
                        <span><?= sprintf($this->language->account->package->subheader, '<strong>' . \Altum\Date::get($this->user->package_expiration_date, 2) . '</strong>') ?></span>
                    <?php endif ?>

                    <?php if($this->settings->payment->is_enabled): ?>
                        <span>(<a href="<?= url('package/upgrade') ?>"><?= $this->language->account->package->renew ?></a>)</span>
                    <?php endif ?>
                </p>

                <?php if($this->user->package_settings->notifications_impressions_limit != -1): ?>
                    <?php
                    $progress_percentage = $this->user->package_settings->notifications_impressions_limit == '0' ? 100 : ($this->user->current_month_notifications_impressions / $this->user->package_settings->notifications_impressions_limit) * 100;
                    $progress_class = $progress_percentage > 60 ? ($progress_percentage > 85 ? 'badge-danger' : 'badge-warning') : 'badge-success';
                    ?>
                    <p class="text-muted">
                        <?=
                            sprintf($this->language->account->package->notifications_impressions_limit,
                                '<span class="badge ' . $progress_class . '">' . nr($progress_percentage) . '%</span>',
                                nr($this->user->package_settings->notifications_impressions_limit)
                            );
                        ?>
                    </p>
                <?php endif ?>



                            
                               
                            </div>
                            
                        </div>
                      
                    </div> -->
                    <div class="row mt-4">
                        <div class="col-6">


                 <br>  <br>  <br>   <br>   

                  <div class="user-greeting-wrap">
                        <div class="user-greeting">
                            Welcome, <span class="user-name"><?= $this->user->name ?></span>
                            <!-- <span class="user-name">Getting Started</span> -->
                        </div>
                        <div class="more-info">
                        <h5>Getting Started </h5><br> 


                        </div>

                   
                        

                        </div>
                          




                        </div>

                        <div class="col-6">
                            <br>  
                            <div class="user-stats-box">
                                <div class="stat-wrap">
                                    <div class="stat-tooltip">
                                        Create Campaign
                                    </div>
                                    <div class="stat-icon-wrap touches-wrap">
                                        <!-- <span class="flaticon-click icons stat-icon"></span> -->

                                        <?php if($this->user->package_settings->campaigns_limit != -1 && $data->campaigns_total >= $this->user->package_settings->campaigns_limit): ?>
                <span type="button" data-confirm="<?= $this->language->campaign->error_message->campaigns_limit ?>"  class=""><img src="https://app.engagrmate.com/icons/one.jpeg" height="70" width="65"></span>
            <?php else: ?>
                <span type="button" data-toggle="modal" data-target="#create_campaign" class=""><img src="https://app.engagrmate.com/icons/one.jpeg" height="70" width="65"></span>
            <?php endif ?>

                                    </div>
                                    <div class="value">
                                        Add
                                    </div>
                                </div>
                                <div class="stat-wrap">
                                    <div class="stat-tooltip">
                                        Facebook Group
                                    </div>
                                    <div class="stat-icon-wrap">
                                        <a href="https://www.facebook.com/groups/315044962852660">
                                        <span class="flaticon-group icons stat-icon"></span> </a>
                                    </div>
                                    <div class="value">
                                        Group
                                    </div>
                                </div>
                                <div class="stat-wrap">
                                    <div class="stat-tooltip">
                                        Tutorials
                                    </div>
                                    <div class="stat-icon-wrap">
                                        <a href="https://engagrmate.com/tutorials/">
                                         <img src="https://app.engagrmate.com/icons/three.jpeg" height="70" width="65">
                                           </a>
                                    </div>
                                    <div class="value">
                                        Tour
                                    </div>
                                </div>
                                <div class="stat-wrap">
                                    <div class="stat-tooltip">
                                        Bonuses
                                    </div>
                                    <div class="stat-icon-wrap">
                                        <a href="https://engagrmate.com/bonuses/"> 
                                         <img src="https://app.engagrmate.com/icons/four.jpeg" height="70" width="65">
                                          </a>
                                    </div>
                                    <div class="value">
                                        Bonuses
                                    </div>
                                </div>
                            </div>
                        </div>



                      <!--   <div class="col-6">
                            <div class="chart-wrap">
                                <div class="user-stats-box">
                                <div class="stat-wrap">
                                    <div class="stat-tooltip">
                                        Create Campaign
                                    </div>
                                    <div class="stat-icon-wrap touches-wrap">

                                        <?php if($this->user->package_settings->campaigns_limit != -1 && $data->campaigns_total >= $this->user->package_settings->campaigns_limit): ?>
                <span type="button" data-confirm="<?= $this->language->campaign->error_message->campaigns_limit ?>"  class=""><img src="https://app.engagrmate.com/icons/logo.png" height="18"></span>
            <?php else: ?>
                <span type="button" data-toggle="modal" data-target="#create_campaign" class=""><img src="https://app.engagrmate.com/icons/one.jpeg" height="70" width="65"></span>
            <?php endif ?>

                                      
                                    </div>
                                    <div class="value">
                                       
                                    </div> 
                                </div>
                                <div class="stat-wrap">
                                    <div class="stat-tooltip">
                                        Facebook Group
                                    </div>
                                    <div class="stat-icon-wrap">
                                        <a href=""><span class="flaticon-group icons stat-icon"></span></a>
                                    </div>
                                    <div class="value">
                                       
                                    </div> 
                                </div>
                                <div class="stat-wrap">
                                    <div class="stat-tooltip">
                                        Tutorials
                                    </div>
                                    <div class="stat-icon-wrap">
                                       <a href=""> <img src="https://app.engagrmate.com/icons/three.jpeg" height="73" width="71"> </a>
                                    </div>
                                     <div class="value">
                                       
                                    </div> 
                                </div>
                                <div class="stat-wrap">
                                    <div class="stat-tooltip">
                                        Bonuses
                                    </div>
                                    <div class="stat-icon-wrap">
                                        <a href=""> <img src="https://app.engagrmate.com/icons/four.jpeg" height="68" width="65"> </a>
                                    </div>
                                     <div class="value">
                                        
                                    </div> 
                                </div>
                            </div>




                            </div>
                        </div> -->


                       
                    </div>
             <?php require THEME_PATH . 'views/partials/ads_header.php' ?>

                    <section>
                    <!-- <?php display_notifications() ?> -->
 <!-- <div class="margin-top-3 d-flex justify-content-between">
                    <div class="col-auto p-0">
            <?php if($this->user->package_settings->campaigns_limit != -1 && $data->campaigns_total >= $this->user->package_settings->campaigns_limit): ?>
                <button type="button" data-confirm="<?= $this->language->campaign->error_message->campaigns_limit ?>"  class="btn btn-create-notification-main">CREATE CAMPAIGN<span class="add-notification-icon-wrap">
                                <span class="flaticon-add icons add-notification-icon"></span>
                            </span></button>
            <?php else: ?>
                <button type="button" data-toggle="modal" data-target="#create_campaign" class="btn btn-create-notification-main">CREATE CAMPAIGN<span class="add-notification-icon-wrap">
                                <span class="flaticon-add icons add-notification-icon"></span>
                            </span></button>
            <?php endif ?>
        </div>
    </div> -->
                     
                    <?php if($data->campaigns_result->num_rows): ?>

                    <div class="container-fluid mt-5">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">FAV</th>
                                    <th scope="col">CAMPAIGN</th>
                                    <th scope="col">DOMAIN</th>
                                    <th scope="col">STATUS</th>
                                    <th scope="col">CREATED</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php while($row = $data->campaigns_result->fetch_object()): ?>

                                <?php
                    $row->branding = json_decode($row->branding);

                    $icon = new \Jdenticon\Identicon([
                        'value' => $row->domain,
                        'size' => 50,
                        'style' => [
                            'hues' => [235],
                            'backgroundColor' => '#86444400',
                            'colorLightness' => [0.41, 0.80],
                            'grayscaleLightness' => [0.30, 0.70],
                            'colorSaturation' => 0.85,
                            'grayscaleSaturation' => 0.40,
                        ]
                    ]);
                    $row->icon = $icon->getImageDataUri();

                    ?> 


                                <tr class="active">
                                    <td> <div class="table-indicator"></div>
                                    <!-- <img src="<?= $row->icon ?>" class="campaign-avatar rounded-circle mr-3" alt="" /> -->
                                    </td>
                                    <td class="clickable" data-href="<?= url('campaign/' . $row->campaign_id) ?>"> 
                                     
                                      <?= $row->name ?> 

                                    </td>


                                    <td class="clickable" data-href="<?= url('campaign/' . $row->campaign_id) ?>">
                                         <?= $row->domain ?>
                                    </td>
                                    <td>
                                        <div class="d-flex">
                                <div class="custom-control custom-switch" data-toggle="tooltip" title="<?= $this->language->dashboard->campaigns->is_enabled_tooltip ?>">
                                    <input
                                            type="checkbox"
                                            class="custom-control-input"
                                            id="campaign_is_enabled_<?= $row->campaign_id ?>"
                                            data-row-id="<?= $row->campaign_id ?>"
                                            onchange="ajax_call_helper(event, 'campaigns-ajax', 'is_enabled_toggle')"
                                        <?= $row->is_enabled ? 'checked="true"' : null ?>
                                    >
                                    <label class="custom-control-label clickable" for="campaign_is_enabled_<?= $row->campaign_id ?>"></label>
                                </div>
                            </div>
                                    </td>
                                    <td class="clickable d-none d-md-table-cell text-muted" data-href="<?= url('campaign/' . $row->campaign_id) ?>"><span><?= \Altum\Date::get($row->date, 2) ?></span>

                                    </td>
                                           

                                    <td>
                                        <nav class="nav manage-campaign">
                                            <div class="dropdown">
                                <a href="#" data-toggle="dropdown" class="text-secondary dropdown-toggle dropdown-toggle-simple">
                                   OPTION <span class="icon-tools-and-utensils edit-icon"></span>

                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a href="#" data-toggle="modal" data-target="#update_campaign" data-campaign-id="<?= $row->campaign_id ?>" data-name="<?= $row->name ?>" data-domain="<?= $row->domain ?>" data-include-subdomains="<?= (bool) $row->include_subdomains ?>" class="dropdown-item"><i class="fa fa-fw fa-sm fa-pencil-alt mr-1"></i> <?= $this->language->global->edit ?></a>

                                        <a
                                            href="#"
                                            data-toggle="modal"
                                            data-target="#campaign_pixel_key"
                                            data-pixel-key="<?= $row->pixel_key ?>"
                                            data-campaign-id="<?= $row->campaign_id ?>"
                                            class="dropdown-item"
                                        ><i class="fa fa-fw fa-sm fa-code mr-1"></i> <?= $this->language->campaign->header->pixel_key ?></a>

                                        <?php if($this->user->package_settings->custom_branding): ?>
                                            <a href="#" data-toggle="modal" data-target="#custom_branding_campaign" data-campaign-id="<?= $row->campaign_id ?>" data-branding-name="<?= $row->branding->name ?? '' ?>" data-branding-url="<?= $row->branding->url ?? '' ?>" class="dropdown-item"><i class="fa fa-fw fa-sm fa-random mr-1"></i> <?= $this->language->campaign->header->custom_branding ?></a>
                                        <?php endif ?>

                                        <a href="#" class="dropdown-item" data-delete="<?= $this->language->global->info_message->confirm_delete ?>" data-row-id="<?= $row->campaign_id ?>"><i class="fa fa-fw fa-sm fa-times mr-1"></i> <?= $this->language->global->delete ?></a>
                                    </div>
                                </a>
                            </div> 
                                            <a class="nav-link" href="#" data-toggle="dropdown">
                                                
                                                

                                            </a>
                                           <!--  <a class="nav-link" href="#">
                                                DELETE
                                                <span class="flaticon-delete icons delete-icon"></span>
                                            </a> -->

                                            <div class="col-auto p-0">
            <?php if($this->user->package_settings->campaigns_limit != -1 && $data->campaigns_total >= $this->user->package_settings->campaigns_limit): ?>
                <button type="button" data-confirm="<?= $this->language->campaign->error_message->campaigns_limit ?>"  class="btn btn-create-notification"><span class="flaticon-add icons add-icon"></span> <!-- <?= $this->language->dashboard->campaigns->create ?> --></button>
            <?php else: ?>
                <button type="button" data-toggle="modal" data-target="#create_campaign" class="btn btn-create-notification"><span class="flaticon-add icons add-icon"></span> <!-- <?= $this->language->dashboard->campaigns->create ?> --></button>
            <?php endif ?>
        </div> 
                                            <!-- <a class="btn btn-create-notification" data-toggle="modal"
                                                data-target="#add-campaign">
                                                <span class="flaticon-add icons add-icon"></span>

                                            </a> -->
                                        </nav>
                                    </td>
                                </tr>
                               


                    <?php endwhile ?>

                            </tbody>
                        </table>
                    </div>


                    <?php else: ?>

        <div class="d-flex flex-column align-items-center justify-content-center">
           <!--  <img src="<?= SITE_URL . ASSETS_URL_PATH . 'images/no_data.svg' ?>" class="col-10 col-md-6 col-lg-4 mb-3" alt="<?= $this->language->global->no_data ?>" /> -->
            <h2 class="h4 text-muted"><?= $this->language->global->no_data ?></h2>
            <p><?= $this->language->dashboard->campaigns->no_data ?></a></p>
        </div>

    <?php endif ?>



                </section>

                <?php ob_start() ?>
<script>
    $('[data-delete]').on('click', event => {
        let message = $(event.currentTarget).attr('data-delete');

        if(!confirm(message)) return false;

        /* Continue with the deletion */
        ajax_call_helper(event, 'campaigns-ajax', 'delete', () => {

            /* On success delete the actual row from the DOM */
            $(event.currentTarget).closest('tr').remove();

        });

        event.preventDefault();
    });

    <?php if(isset($_GET['pixel_key_modal'])): ?>

    /* Open the pixel key modal */
    $('[data-campaign-id="<?= (int) $_GET['pixel_key_modal'] ?>"][data-pixel-key]').trigger('click');

    <?php endif ?>

</script>
<?php \Altum\Event::add_content(ob_get_clean(), 'javascript') ?>


                </div>
            </div>
        </div>
    </div>

    </div>
    <div class="modal" id="add-campaign">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h5 class="modal-title">Create New Campaign</h5>
                    <span type="button" class="close flaticon-error icons close-add-workspace"
                        data-dismiss="modal"></span>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action method="post">
                        <div class="form-group">
                            <label for="campaign-name">Name</label>
                            <input type="text" name="campaign-name" id="campaign-name" class="form-control"
                                placeholder="Enter a name for your campaign" />
                        </div>
                        <div class="form-group">
                            <label for="domain-url">Domain / Subdomain</label>
                            <input type="text" name="domain-url" id="domain-url" class="form-control"
                                placeholder="ex. domain.com, subdomain.domain.com" />
                            <small class="text-muted">
                                The domain name of the site where the campaign is going to run. Notification will NOT
                                work on other domain other than what you define here.
                            </small>
                        </div>
                        <div class="d-flex align-items-center">
                            <label class="switch">
                                <input id="include-subdomains-check" type="checkbox">
                                <span class="slider round"></span>
                            </label>
                            <div class="d-flex flex-column ml-4">
                            <label for="include-subdomains-check">Include Subdomains</label>
                            <small class="text-muted">All subdomain will match on this canpaign if checked.</small>
                            </div>
                            
                        </div>
                        <div class="d-flex justify-content-center mt-4">
                            <button type="button" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
   