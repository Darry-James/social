<?php
defined('ALTUMCODE') || die();

/* Create the content for each tab */
$html = [];

/* Extra Javascript needed */
$javascript = '';

return (object) ['html' => $html, 'javascript' => $javascript];
