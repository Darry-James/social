<?php defined('ALTUMCODE') || die() ?>




    <div class="container-fluid no-gutters">
        <div class="d-flex">
            <div class="sidebar">
                

               <nav class="navbar flex-column sidebar-contents">
                    <div class="navbar-collapse">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-item active">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="flaticon-megaphone icons nav-icon"></span>
                                   My plan
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           <!--  <li class="nav-item active">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                             <li class="nav-item">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Package
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-payments">
                                    <span class="fa fa-fw fa fa-dollar-sign icons nav-icon"></span>
                                    Payments
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           
                           <li class="nav-item">
                                <a class="nav-link" href="logout">
                                    <span class="fa fa-fw fa fa-sign-out-alt icons nav-icon"></span>
                                    Logout
                                </a>
                            </li> -->

                            <li class="nav-item mb-0">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>
                            <ul class="nav nav-item settings-sub-nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/tutorials/">Tutorials</a>
                                </li>
                                <!-- <li class="nav-item">
                                    <a class="nav-link" href="#">Support</a>
                                </li> -->
                                <li class="nav-item">
                                    <a class="nav-link" href="account-payments">Billing</a>
                                </li>
                                
                            </ul>

                            <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/bonuses/">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Bonuses
                                     </a>
                                </li>

                            <li class="nav-item">
                                <a class="nav-link" href="https://patrienickhelp.freshdesk.com/support/home">
                                    <span class="flaticon-information icons nav-icon"></span>
                                    Knowledge Base
                                </a>
                            </li>


                        </ul>


                    </div>
               <div>
                        <a class="btn" href="logout">
                            <img class="logout" src="<?= SITE_URL . ASSETS_URL_PATH . 'logout.svg' ?>" alt="log out">
                        </a>
                    </div>
                </nav>

            </div>
            <div class="container-fluid flex-grow-1">
                <!-- <div class="d-flex justify-content-between header-wrap">
                    <div class="user-greeting-wrap">
                        <div class="user-greeting">
                            Welcome,
                            <span class="user-name">Ejem Austine O.</span>
                        </div>
                        <div class="more-info">
                            To get started, kindly refer to our quick checklist
                            <span class="flaticon-interface-1 icons checklist-icon"></span>
                        </div>
                    </div>
                    <div class="d-flex section-right">
                        <div class="guide-btn-wrap">
                            <a name="btn-help-desk" id="btn-help-desk" class="btn btn-help-desk" href="#"
                                role="button">HELP DESK</a>
                            <a name="btn-tour-guide" id="btn-tour-guide" class="btn btn-tour-guide" href="#"
                                role="button">TOUR GUIDE</a>
                        </div>
                        <div class="notification-wrap">
                            <span class="flaticon-music-and-multimedia icons notification-icon"></span>
                        </div>
                        <user-image-icon></user-image-icon>
                    </div>
                </div> -->
                <div class="d-flex flex-column align-items-end">
                    <div class="d-flex justify-content-between header-wrap">
                        <div class="title-wrap">
                            


                    <header>
    <div>

        <?php

        $icon = new \Jdenticon\Identicon([
            'value' => $data->campaign->domain,
            'size' => 100,
            'style' => [
                'hues' => [235],
                'backgroundColor' => '#86444400',
                'colorLightness' => [0.41, 0.80],
                'grayscaleLightness' => [0.30, 0.70],
                'colorSaturation' => 0.85,
                'grayscaleSaturation' => 0.40,
            ]
        ]);
        $data->campaign->icon = $icon->getImageDataUri();

        ?>

        <div class="d-flex">
            <!-- <img src="<?= $data->campaign->icon ?>" class="campaign-big-avatar rounded-circle mr-3" alt="" /> -->

            <div class="d-flex flex-column flex-grow-1">
                <div class="d-flex flex-column flex-md-row align-items-md-center">
                    <h1 class="h2 mr-3"><span class=""><?= $data->campaign->name ?></span></h1>

                    <div class="d-flex">
                        <div class="custom-control custom-switch mr-3" data-toggle="tooltip" title="<?= $this->language->dashboard->campaigns->is_enabled_tooltip ?>">
                            <input
                                    type="checkbox"
                                    class="custom-control-input"
                                    id="campaign_is_enabled_<?= $data->campaign->campaign_id ?>"
                                    data-row-id="<?= $data->campaign->campaign_id ?>"
                                    onchange="ajax_call_helper(event, 'campaigns-ajax', 'is_enabled_toggle')"
                                    <?= $data->campaign->is_enabled ? 'checked="true"' : null ?>
                            >
                            <label class="custom-control-label clickable" for="campaign_is_enabled_<?= $data->campaign->campaign_id ?>"></label>
                        </div>

                        <div class="dropdown">
                            <a href="#" data-toggle="dropdown" class="text-secondary dropdown-toggle dropdown-toggle-simple">
                                <i class="fa fa-ellipsis-v"></i>

                                <div class="dropdown-menu dropdown-menu-right">
                                    <a href="#" data-toggle="modal" data-target="#update_campaign" data-campaign-id="<?= $data->campaign->campaign_id ?>" data-name="<?= $data->campaign->name ?>" data-domain="<?= $data->campaign->domain ?>" data-include-subdomains="<?= (bool) $data->campaign->include_subdomains ?>" class="dropdown-item"><i class="fa fa-fw fa-sm fa-pencil-alt mr-1"></i> <?= $this->language->global->edit ?></a>

                                    <a
                                        href="#"
                                        data-toggle="modal"
                                        data-target="#campaign_pixel_key"
                                        data-pixel-key="<?= $data->campaign->pixel_key ?>"
                                        class="dropdown-item"
                                    ><i class="fa fa-fw fa-sm fa-code mr-1"></i> <?= $this->language->campaign->header->pixel_key ?></a>

                                    <?php if($this->user->package_settings->custom_branding): ?>
                                    <a href="#" data-toggle="modal" data-target="#custom_branding_campaign" data-campaign-id="<?= $data->campaign->campaign_id ?>" data-branding-name="<?= $data->campaign->branding->name ?? '' ?>" data-branding-url="<?= $data->campaign->branding->url ?? '' ?>" class="dropdown-item"><i class="fa fa-fw fa-sm fa-random mr-1"></i> <?= $this->language->campaign->header->custom_branding ?></a>
                                    <?php endif ?>

                                    <a href="#" class="dropdown-item" data-delete="<?= $this->language->global->info_message->confirm_delete ?>" data-row-id="<?= $data->campaign->campaign_id ?>"><i class="fa fa-fw fa-sm fa-times mr-1"></i> <?= $this->language->global->delete ?></a>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="d-flex align-items-center text-muted">
                    <img src="https://www.google.com/s2/favicons?domain=<?= $data->campaign->domain ?>" class="img-fluid mr-1" /> <?= $data->campaign->domain ?>
                </div>

            </div>
        </div>

    </div>
</header>

<?php require THEME_PATH . 'views/partials/ads_header.php' ?>


                    </div>
                        <div class="d-flex section-right">
                            <div class="guide-btn-wrap">
                                <a name="btn-help-desk" id="btn-help-desk" class="btn btn-help-desk" href="https://patrienickhelp.freshdesk.com/support/tickets/new"
                                    role="button">HELP DESK</a>
                                <a name="btn-tour-guide" id="btn-tour-guide" class="btn btn-tour-guide" href="https://engagrmate.com/tutorials/"
                                    role="button">TOUR GUIDE</a>
                            </div>
                            <div class="notification-wrap">
                                <span class="flaticon-music-and-multimedia icons notification-icon"></span>
                            </div>
                            <div class="user-icon">
                                <a href="dashboard">
                                    <span class="flaticon-user icons user-icon-default">

                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>


                  <?php display_notifications() ?>

                <div class="d-flex justify-content-between w-100 mt-4">
                  <?php if($this->user->package_settings->notifications_limit != -1 && $data->notifications_total >= $this->user->package_settings->notifications_limit): ?>
                <button type="button" data-confirm="<?= $this->language->notification->error_message->notifications_limit ?>" class="btn btn-create-notification-main">CREATE NOTIFICATIONS<!-- <?= $this->language->campaign->notifications->create ?> --> <span class="add-notification-icon-wrap">
                                <span class="flaticon-add icons add-notification-icon"></span>
                            </span></button>
            <?php else: ?>
                <a href="<?= url('notification-create/' . $data->campaign->campaign_id) ?>" class="btn btn-create-notification-main">CREATE NOTIFICATIONS<!-- <?= $this->language->campaign->notifications->create ?> --> <span class="add-notification-icon-wrap">
                                <span class="flaticon-add icons add-notification-icon"></span>
                            </span></a>
            <?php endif ?>
        </div>

        </div>





               <?php if($data->notifications_result->num_rows): ?>

                <div class="container-fluid">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">FAV</th>
                                <th scope="col">CAMPAIGN</th>
                                <th scope="col">TRIGGER</th>
                                <th scope="col">DURATION</th>
                                <th scope="col">STATUS</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php while($row = $data->notifications_result->fetch_object()): ?>
                    <?php $row->settings = json_decode($row->settings) ?>


                            <tr class="active">
                                <td>
                                   <div class="table-indicator"></div>

                                </td>
                                <td class="clickable" data-href="<?= url('notification/' . $row->notification_id) ?>">
                                    <?= $row->name ?>
                                    <div class="text-muted">
                                    <i class="<?= $this->language->notification->{strtolower($row->type)}->icon ?> fa-sm mr-1"></i> <?= $this->language->notification->{strtolower($row->type)}->name ?>
                                </div>
                                    
                                </td>
                                <td class="clickable d-none d-md-table-cell" data-href="<?= url('notification/' . $row->notification_id) ?>">
                                    <div class="text-muted d-flex flex-column">

                                <?php
                                switch($row->settings->display_trigger) {
                                    case 'delay':

                                        echo '<span>' . $row->settings->display_trigger_value . ' <small>' . $this->language->global->date->seconds . '</small></span>';
                                        echo '<small>' . $this->language->notification->settings->{'display_trigger_' . $row->settings->display_trigger} . '</small>';

                                        break;

                                    case 'scroll':

                                        echo $row->settings->display_trigger_value . '%';
                                        echo '<small>' . $this->language->notification->settings->{'display_trigger_' . $row->settings->display_trigger}  . '</small>';

                                        break;

                                    case 'exit_intent':

                                        echo $this->language->notification->settings->{'display_trigger_' . $row->settings->display_trigger};

                                        break;
                                }
                                ?>

                            </div>
                                    
                                </td>

                                <td class="clickable d-none d-md-table-cell" data-href="<?= url('notification/' . $row->notification_id) ?>">
                            <span><?= $row->settings->display_duration == -1 ? $this->language->campaign->notifications->display_duration_unlimited : $row->settings->display_duration . ' <small>' . $this->language->global->date->seconds . '</small>' ?></span>
                                    
                                </td>



                                <td>
                                    <label class="switch notification">
                                        <div class="custom-control custom-switch" data-toggle="tooltip" title="<?= $this->language->campaign->notifications->is_enabled_tooltip ?>">
                                    <input
                                            type="checkbox"
                                            class="custom-control-input"
                                            id="notification_is_enabled_<?= $row->notification_id ?>"
                                            data-row-id="<?= $row->notification_id ?>"
                                            onchange="ajax_call_helper(event, 'notifications-ajax', 'is_enabled_toggle')"
                                        <?= $row->is_enabled ? 'checked="true"' : null ?>
                                    >
                                    <label class="custom-control-label clickable" for="notification_is_enabled_<?= $row->notification_id ?>"></label>
                                </div>
                                    </label>
                                </td>
                                
                                <td>
                                    <nav class="nav manage-campaign">
                                    
                                               <a class="nav-link" href="<?= url('notification/' . $row->notification_id) ?>"> EDIT <span class="icon-tools-and-utensils edit-icon"></span> </a>
                                            
                                        
                                         <a class="nav-link" href="<?= url('notification/' . $row->notification_id . '/statistics')  ?>">STATISTICS <span class="flaticon-line-chart icons stat-icon"></span> </a>

                                      
                                        <a href="#" class="nav-link" data-delete="<?= $this->language->global->info_message->confirm_delete ?>" data-row-id="<?= $row->notification_id ?>">DELETE <span class="flaticon-delete icons delete-icon"></span> </a>


                                        
                                    </nav>
                                </td>
                            </tr>
                         <?php endwhile ?>
                        </tbody>
                    </table>
                </div>

                <?php else: ?>

        <div class="d-flex flex-column align-items-center justify-content-center">
           <!--  <img src="<?= SITE_URL . ASSETS_URL_PATH . 'images/no_data.svg' ?>" class="col-10 col-md-6 col-lg-4 mb-3" alt="<?= $this->language->global->no_data ?>" /> -->
            <h2 class="h4 text-muted"><?= $this->language->global->no_data ?></h2>
            <p><?= $this->language->campaign->notifications->no_data ?></a></p>
        </div>

    <?php endif ?>
            </div>

            <?php ob_start() ?>
<script>
    $(document).ready(() => {
        $('[data-delete]').on('click', event => {
            let message = $(event.currentTarget).attr('data-delete');

            if(!confirm(message)) return false;

            /* Continue with the deletion */
            ajax_call_helper(event, 'notifications-ajax', 'delete', () => {

                /* On success delete the actual row from the DOM */
                $(event.currentTarget).closest('tr').remove();

            });

        });
    });
</script>
<?php \Altum\Event::add_content(ob_get_clean(), 'javascript') ?>


        </div>
    </div>

    <!-- <script src="https://unpkg.com/@popperjs/core@2"></script> -->
    <script src="../assets/js/jquery/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="../assets/js/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/js/custom/main.js"></script>
</body>

</html>