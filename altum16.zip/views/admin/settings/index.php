<?php defined('ALTUMCODE') || die() ?>

<div class="d-flex mb-4">
    <h1 class="h3"><i class="fa fa-fw fa-xs fa-wrench text-primary-900 mr-2"></i> <?= $this->language->admin_settings->header ?></h1>
</div>

<?php display_notifications() ?>

<div class="row">
    <div class="mb-5 mb-xl-0 col-12 col-xl-3">
        <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
            <a class="nav-link active" href="#main" data-toggle="pill" role="tab"><i class="fa fa-fw fa-sm fa-home mr-1"></i> <?= $this->language->admin_settings->tab->main ?></a>
            <a class="nav-link" href="#payment" data-toggle="pill" role="tab"><i class="fa fa-fw fa-sm fa-dollar-sign mr-1"></i> <?= $this->language->admin_settings->tab->payment ?></a>
            <a class="nav-link" href="#business" data-toggle="pill" role="tab"><i class="fa fa-fw fa-sm fa-briefcase mr-1"></i> <?= $this->language->admin_settings->tab->business ?></a>
            <a class="nav-link" href="#socialproofo" data-toggle="pill" role="tab"><i class="fa fa-fw fa-sm fa-share-alt mr-1"></i> <?= $this->language->admin_settings->tab->socialproofo ?></a>
            <a class="nav-link" href="#captcha" data-toggle="pill" role="tab"><i class="fa fa-fw fa-sm fa-low-vision mr-1"></i> <?= $this->language->admin_settings->tab->captcha ?></a>
            <a class="nav-link" href="#facebook" data-toggle="pill" role="tab"><i class="fab fa-fw fa-sm fa-facebook mr-1"></i> <?= $this->language->admin_settings->tab->facebook ?></a>
            <a class="nav-link" href="#ads" data-toggle="pill" role="tab"><i class="fa fa-fw fa-sm fa-ad mr-1"></i> <?= $this->language->admin_settings->tab->ads ?></a>
            <a class="nav-link" href="#socials" data-toggle="pill" role="tab"><i class="fab fa-fw fa-sm fa-instagram mr-1"></i> <?= $this->language->admin_settings->tab->socials ?></a>
            <a class="nav-link" href="#smtp" data-toggle="pill" role="tab"><i class="fa fa-fw fa-sm fa-mail-bulk mr-1"></i> <?= $this->language->admin_settings->tab->smtp ?></a>
            <a class="nav-link" href="#custom" data-toggle="pill" role="tab"><i class="fa fa-fw fa-sm fa-paint-brush mr-1"></i> <?= $this->language->admin_settings->tab->custom ?></a>
            <a class="nav-link" href="#email_notifications" data-toggle="pill" role="tab"><i class="fa fa-fw fa-sm fa-bell mr-1"></i> <?= $this->language->admin_settings->tab->email_notifications ?></a>
            <a class="nav-link" href="#cron" data-toggle="pill" role="tab"><i class="fa fa-fw fa-sm fa-sync mr-1"></i> <?= $this->language->admin_settings->tab->cron ?></a>
            <a class="nav-link" href="#license" data-toggle="pill" role="tab"><i class="fa fa-fw fa-sm fa-key mr-1"></i> <?= $this->language->admin_settings->tab->license ?></a>
        </div>
    </div>

    <div class="col order-1 order-xl-0">
        <div class="card">
            <div class="card-body">

                <form action="" method="post" role="form" enctype="multipart/form-data">
                    <input type="hidden" name="token" value="<?= \Altum\Middlewares\Csrf::get() ?>" />

                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="main">
                            <div class="form-group">
                                <label><i class="fa fa-fw fa-sm fa-heading text-muted mr-1"></i> <?= $this->language->admin_settings->main->title ?></label>
                                <input type="text" name="title" class="form-control form-control-lg" value="<?= $this->settings->title ?>" />
                            </div>

                            <div class="form-group">
                                <label><i class="fa fa-fw fa-sm fa-language text-muted mr-1"></i> <?= $this->language->admin_settings->main->default_language ?></label>
                                <select name="default_language" class="form-control form-control-lg">
                                    <?php foreach(\Altum\Language::$languages as $value) echo '<option value="' . $value . '" ' . (($this->settings->default_language == $value) ? 'selected' : null) . '>' . $value . '</option>' ?>
                                </select>
                                <small class="text-muted"><?= $this->language->admin_settings->main->default_language_help ?></small>
                            </div>

                            <div class="form-group">
                                <label><i class="fa fa-fw fa-sm fa-eye text-muted mr-1"></i> <?= $this->language->admin_settings->main->logo ?></label>
                                <?php if($this->settings->logo != ''): ?>
                                    <div class="m-1">
                                        <img src="<?= SITE_URL . UPLOADS_URL_PATH . 'logo/' . $this->settings->logo ?>" class="img-fluid" style="max-height: 2.5rem;height: 2.5rem;" />
                                    </div>
                                <?php endif ?>
                                <input id="logo-file-input" type="file" name="logo" accept=".gif, .ico, .png, .jpg, .jpeg, .svg" class="form-control form-control-lg" />
                                <small class="text-muted"><?= $this->language->admin_settings->main->logo_help ?></small>
                                <small class="text-muted"><a href="admin/settings/removelogo<?= \Altum\Middlewares\Csrf::get_url_query() ?>"><?= $this->language->admin_settings->main->logo_remove ?></a></small>
                            </div>

                            <div class="form-group">
                                <label><i class="fa fa-fw fa-sm fa-icons text-muted mr-1"></i> <?= $this->language->admin_settings->main->favicon ?></label>
                                <?php if($this->settings->favicon != ''): ?>
                                    <div class="m-1">
                                        <img src="<?= SITE_URL . UPLOADS_URL_PATH . 'favicon/' . $this->settings->favicon ?>" class="img-fluid" style="max-height: 32px;height: 32px;" />
                                    </div>
                                <?php endif ?>
                                <input id="favicon-file-input" type="file" name="favicon" accept=".gif, .ico, .png, .jpg, .jpeg, .svg" class="form-control form-control-lg" />
                                <small class="text-muted"><?= $this->language->admin_settings->main->favicon_help ?></small>
                                <small class="text-muted"><a href="admin/settings/removefavicon<?= \Altum\Middlewares\Csrf::get_url_query() ?>"><?= $this->language->admin_settings->main->favicon_remove ?></a></small>
                            </div>

                            <div class="form-group">
                                <label><i class="fa fa-fw fa-sm fa-atlas text-muted mr-1"></i> <?= $this->language->admin_settings->main->default_timezone ?></label>
                                <select name="default_timezone" class="form-control form-control-lg">
                                    <?php foreach(DateTimeZone::listIdentifiers() as $time_zone) echo '<option value="' . $time_zone . '" ' . (($this->settings->default_timezone == $time_zone) ? 'selected' : null) . '>' . $time_zone . '</option>' ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label><i class="fa fa-fw fa-sm fa-envelope text-muted mr-1"></i> <?= $this->language->admin_settings->main->email_confirmation ?></label>

                                <select class="form-control form-control-lg" name="email_confirmation">
                                    <option value="1" <?= $this->settings->email_confirmation ? 'selected' : null ?>><?= $this->language->global->yes ?></option>
                                    <option value="0" <?= !$this->settings->email_confirmation ? 'selected' : null ?>><?= $this->language->global->no ?></option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label><i class="fa fa-fw fa-sm fa-users text-muted mr-1"></i> <?= $this->language->admin_settings->main->register_is_enabled ?></label>

                                <select class="form-control form-control-lg" name="register_is_enabled">
                                    <option value="1" <?= $this->settings->register_is_enabled ? 'selected' : null ?>><?= $this->language->global->yes ?></option>
                                    <option value="0" <?= !$this->settings->register_is_enabled ? 'selected' : null ?>><?= $this->language->global->no ?></option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label><i class="fa fa-fw fa-sm fa-sitemap text-muted mr-1"></i> <?= $this->language->admin_settings->main->index_url ?></label>
                                <input type="text" name="index_url" class="form-control form-control-lg" value="<?= $this->settings->index_url ?>" />
                                <small class="text-muted"><?= $this->language->admin_settings->main->index_url_help ?></small>
                            </div>

                            <div class="form-group">
                                <label><i class="fa fa-fw fa-sm fa-file-word text-muted mr-1"></i> <?= $this->language->admin_settings->main->terms_and_conditions_url ?></label>
                                <input type="text" name="terms_and_conditions_url" class="form-control form-control-lg" value="<?= $this->settings->terms_and_conditions_url ?>" />
                                <small class="text-muted"><?= $this->language->admin_settings->main->terms_and_conditions_url_help ?></small>
                            </div>

                            <div class="form-group">
                                <label><i class="fa fa-fw fa-sm fa-file-word text-muted mr-1"></i> <?= $this->language->admin_settings->main->privacy_policy_url ?></label>
                                <input type="text" name="privacy_policy_url" class="form-control form-control-lg" value="<?= $this->settings->privacy_policy_url ?>" />
                                <small class="text-muted"><?= $this->language->admin_settings->main->privacy_policy_url_help ?></small>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="payment">
                            <?php if(!in_array($this->settings->license->type, ['SPECIAL','Extended License'])): ?>
                                <div class="alert alert-primary" role="alert">
                                    You need to own the Extended License in order to activate the payment system.
                                </div>
                            <?php endif ?>

                            <div class="<?= !in_array($this->settings->license->type, ['SPECIAL','Extended License']) ? 'container-disabled' : null ?>">
                                <div class="form-group">
                                    <label><i class="fa fa-fw fa-sm fa-dollar-sign text-muted mr-1"></i> <?= $this->language->admin_settings->payment->is_enabled ?></label>

                                    <select name="payment_is_enabled" class="form-control form-control-lg">
                                        <option value="1" <?= $this->settings->payment->is_enabled ? 'selected' : null ?>><?= $this->language->global->yes ?></option>
                                        <option value="0" <?= !$this->settings->payment->is_enabled ? 'selected' : null ?>><?= $this->language->global->no ?></option>
                                    </select>
                                    <small class="text-muted"><?= $this->language->admin_settings->payment->is_enabled_help ?></small>
                                </div>

                                <div class="form-group">
                                    <label><i class="fa fa-fw fa-sm fa-credit-card text-muted mr-1"></i> <?= $this->language->admin_settings->payment->type ?></label>

                                    <select name="payment_type" class="form-control form-control-lg">
                                        <option value="one-time" <?= $this->settings->payment->type == 'one-time' ? 'selected' : null ?>><?= $this->language->admin_settings->payment->type_one_time ?></option>
                                        <option value="recurring" <?= $this->settings->payment->type == 'recurring' ? 'selected' : null ?>><?= $this->language->admin_settings->payment->type_recurring ?></option>
                                        <option value="both" <?= $this->settings->payment->type == 'both' ? 'selected' : null ?>><?= $this->language->admin_settings->payment->type_both ?></option>
                                    </select>
                                    <small class="text-muted"><?= $this->language->admin_settings->payment->type_help ?></small>
                                </div>

                                <div class="form-group">
                                    <label><i class="fa fa-fw fa-sm fa-copyright text-muted mr-1"></i> <?= $this->language->admin_settings->payment->brand_name ?></label>
                                    <input type="text" name="payment_brand_name" class="form-control form-control-lg" value="<?= $this->settings->payment->brand_name ?>" />
                                    <small class="text-muted"><?= $this->language->admin_settings->payment->brand_name_help ?></small>
                                </div>

                                <div class="form-group">
                                    <label><i class="fa fa-fw fa-sm fa-coins text-muted mr-1"></i> <?= $this->language->admin_settings->payment->currency ?></label>
                                    <input type="text" name="payment_currency" class="form-control form-control-lg" value="<?= $this->settings->payment->currency ?>" />
                                    <small class="text-muted"><?= $this->language->admin_settings->payment->currency_help ?></small>
                                </div>

                                <div class="form-group">
                                    <label><i class="fa fa-fw fa-sm fa-tags text-muted mr-1"></i> <?= $this->language->admin_settings->payment->codes_is_enabled ?></label>

                                    <select name="payment_codes_is_enabled" class="form-control form-control-lg">
                                        <option value="1" <?= $this->settings->payment->codes_is_enabled ? 'selected' : null ?>><?= $this->language->global->yes ?></option>
                                        <option value="0" <?= !$this->settings->payment->codes_is_enabled ? 'selected' : null ?>><?= $this->language->global->no ?></option>
                                    </select>
                                    <small class="text-muted"><?= $this->language->admin_settings->payment->codes_is_enabled_help ?></small>
                                </div>

                                <hr class="my-3">

                                <p class="h5"><i class="fab fa-fw fa-sm fa-sm fa-paypal icon-paypal"></i> <?= $this->language->admin_settings->payment->paypal ?></p>
                                <p class="text-muted"><?= $this->language->admin_settings->documentation ?></p>

                                <div class="form-group">
                                    <label><?= $this->language->admin_settings->payment->paypal_is_enabled ?></label>

                                    <select name="paypal_is_enabled" class="form-control form-control-lg">
                                        <option value="1" <?= $this->settings->paypal->is_enabled ? 'selected' : null ?>><?= $this->language->global->yes ?></option>
                                        <option value="0" <?= !$this->settings->paypal->is_enabled ? 'selected' : null ?>><?= $this->language->global->no ?></option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label><?= $this->language->admin_settings->payment->paypal_mode ?></label>

                                    <select name="paypal_mode" class="form-control form-control-lg">
                                        <option value="live" <?= $this->settings->paypal->mode == 'live' ? 'selected' : null ?>>live</option>
                                        <option value="sandbox" <?= $this->settings->paypal->mode == 'sandbox' ? 'selected' : null ?>>sandbox</option>
                                    </select>

                                    <small class="text-muted"><?= $this->language->admin_settings->payment->paypal_mode_help ?></small>
                                </div>

                                <div class="form-group">
                                    <label><?= $this->language->admin_settings->payment->paypal_client_id ?></label>
                                    <input type="text" name="paypal_client_id" class="form-control form-control-lg" value="<?= $this->settings->paypal->client_id ?>" />
                                </div>

                                <div class="form-group">
                                    <label><?= $this->language->admin_settings->payment->paypal_secret ?></label>
                                    <input type="text" name="paypal_secret" class="form-control form-control-lg" value="<?= $this->settings->paypal->secret ?>" />
                                </div>

                                <hr class="my-3">

                                <p class="h5"><i class="fab fa-fw fa-sm fa-sm fa-stripe icon-stripe"></i> <?= $this->language->admin_settings->payment->stripe ?></p>
                                <p class="text-muted"><?= $this->language->admin_settings->documentation ?></p>

                                <div class="form-group">
                                    <label><?= $this->language->admin_settings->payment->stripe_is_enabled ?></label>

                                    <select name="stripe_is_enabled" class="form-control form-control-lg">
                                        <option value="1" <?= $this->settings->stripe->is_enabled ? 'selected' : null ?>><?= $this->language->global->yes ?></option>
                                        <option value="0" <?= !$this->settings->stripe->is_enabled ? 'selected' : null ?>><?= $this->language->global->no ?></option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label><?= $this->language->admin_settings->payment->stripe_publishable_key ?></label>
                                    <input type="text" name="stripe_publishable_key" class="form-control form-control-lg" value="<?= $this->settings->stripe->publishable_key ?>" />
                                </div>

                                <div class="form-group">
                                    <label><?= $this->language->admin_settings->payment->stripe_secret_key ?></label>
                                    <input type="text" name="stripe_secret_key" class="form-control form-control-lg" value="<?= $this->settings->stripe->secret_key ?>" />
                                </div>

                                <div class="form-group">
                                    <label><?= $this->language->admin_settings->payment->stripe_webhook_secret ?></label>
                                    <input type="text" name="stripe_webhook_secret" class="form-control form-control-lg" value="<?= $this->settings->stripe->webhook_secret ?>" />
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="business">
                            <p class="h5"><?= $this->language->admin_settings->business->header ?></p>
                            <p class="text-muted"><?= $this->language->admin_settings->business->subheader ?></p>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->business->invoice_is_enabled ?></label>

                                <select name="business_invoice_is_enabled" class="form-control form-control-lg">
                                    <option value="1" <?= $this->settings->business->invoice_is_enabled ? 'selected' : null ?>><?= $this->language->global->yes ?></option>
                                    <option value="0" <?= !$this->settings->business->invoice_is_enabled ? 'selected' : null ?>><?= $this->language->global->no ?></option>
                                </select>

                                <small class="text-muted"><?= $this->language->admin_settings->business->invoice_is_enabled_help ?></small>
                            </div>

                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->name ?></label>
                                        <input type="text" name="business_name" class="form-control form-control-lg" value="<?= $this->settings->business->name ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->email ?></label>
                                        <input type="text" name="business_email" class="form-control form-control-lg" value="<?= $this->settings->business->email ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->phone ?></label>
                                        <input type="text" name="business_phone" class="form-control form-control-lg" value="<?= $this->settings->business->phone ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->tax_type ?></label>
                                        <input type="text" name="business_tax_type" class="form-control form-control-lg" value="<?= $this->settings->business->tax_type ?>" placeholder="<?= $this->language->admin_settings->business->tax_type_placeholder ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->tax_id ?></label>
                                        <input type="text" name="business_tax_id" class="form-control form-control-lg" value="<?= $this->settings->business->tax_id ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->custom_key_one ?></label>
                                        <input type="text" name="business_custom_key_one" class="form-control form-control-lg" value="<?= $this->settings->business->custom_key_one ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->custom_key_two ?></label>
                                        <input type="text" name="business_custom_key_two" class="form-control form-control-lg" value="<?= $this->settings->business->custom_key_two ?>" />
                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->address ?></label>
                                        <input type="text" name="business_address" class="form-control form-control-lg" value="<?= $this->settings->business->address ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->city ?></label>
                                        <input type="text" name="business_city" class="form-control form-control-lg" value="<?= $this->settings->business->city ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->county ?></label>
                                        <input type="text" name="business_county" class="form-control form-control-lg" value="<?= $this->settings->business->county ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->zip ?></label>
                                        <input type="text" name="business_zip" class="form-control form-control-lg" value="<?= $this->settings->business->zip ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->country ?></label>
                                        <input type="text" name="business_country" class="form-control form-control-lg" value="<?= $this->settings->business->country ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->custom_value_one ?></label>
                                        <input type="text" name="business_custom_value_one" class="form-control form-control-lg" value="<?= $this->settings->business->custom_value_one ?>" />
                                    </div>

                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->business->custom_value_two ?></label>
                                        <input type="text" name="business_custom_value_two" class="form-control form-control-lg" value="<?= $this->settings->business->custom_value_two ?>" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="socialproofo">
                            <div class="form-group">
                                <label><i class="fa fa-fw fa-sm fa-chart-bar text-muted mr-1"></i> <?= $this->language->admin_settings->socialproofo->analytics_is_enabled ?></label>

                                <select name="socialproofo_analytics_is_enabled" class="form-control form-control-lg">
                                    <option value="1" <?= $this->settings->socialproofo->analytics_is_enabled ? 'selected' : null ?>><?= $this->language->global->yes ?></option>
                                    <option value="0" <?= !$this->settings->socialproofo->analytics_is_enabled ? 'selected' : null ?>><?= $this->language->global->no ?></option>
                                </select>
                                <small class="text-muted"><?= $this->language->admin_settings->socialproofo->analytics_is_enabled_help ?></small>
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->socialproofo->pixel_cache ?></label>
                                <input type="number" min="0" name="socialproofo_pixel_cache" class="form-control form-control-lg" value="<?= $this->settings->socialproofo->pixel_cache ?>" />
                                <small class="text-muted"><?= $this->language->admin_settings->socialproofo->pixel_cache_help ?></small>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="ads">
                            <p class="text-muted"><?= $this->language->admin_settings->ads->ads_help ?></p>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->ads->header ?></label>
                                <textarea class="form-control form-control-lg" name="ads_header"><?= $this->settings->ads->header ?></textarea>
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->ads->footer ?></label>
                                <textarea class="form-control form-control-lg" name="ads_footer"><?= $this->settings->ads->footer ?></textarea>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="captcha">
                            <p class="h5"><i class="fab fa-fw fa-sm fa-google fa-sm text-muted mr-1"></i> <?= $this->language->admin_settings->captcha->recaptcha ?></p>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->captcha->recaptcha_is_enabled ?></label>

                                <select name="captcha_recaptcha_is_enabled" class="form-control form-control-lg">
                                    <option value="1" <?= $this->settings->captcha->recaptcha_is_enabled ? 'selected' : null ?>><?= $this->language->global->yes ?></option>
                                    <option value="0" <?= !$this->settings->captcha->recaptcha_is_enabled ? 'selected' : null ?>><?= $this->language->global->no ?></option>
                                </select>

                                <small class="text-muted"><?= $this->language->admin_settings->captcha->recaptcha_is_enabled_help ?></small>
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->captcha->recaptcha_public_key ?></label>
                                <input type="text" name="captcha_recaptcha_public_key" class="form-control form-control-lg" value="<?= $this->settings->captcha->recaptcha_public_key ?>" />
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->captcha->recaptcha_private_key ?></label>
                                <input type="text" name="captcha_recaptcha_private_key" class="form-control form-control-lg" value="<?= $this->settings->captcha->recaptcha_private_key ?>" />
                            </div>
                        </div>

                        <div class="tab-pane fade" id="facebook">
                            <div class="form-group">
                                <label><?= $this->language->admin_settings->facebook->is_enabled ?></label>

                                <select name="facebook_is_enabled" class="form-control form-control-lg">
                                    <option value="1" <?= $this->settings->facebook->is_enabled ? 'selected' : null ?>><?= $this->language->global->yes ?></option>
                                    <option value="0" <?= !$this->settings->facebook->is_enabled ? 'selected' : null ?>><?= $this->language->global->no ?></option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->facebook->app_id ?></label>
                                <input type="text" name="facebook_app_id" class="form-control form-control-lg" value="<?= $this->settings->facebook->app_id ?>" />
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->facebook->app_secret ?></label>
                                <input type="text" name="facebook_app_secret" class="form-control form-control-lg" value="<?= $this->settings->facebook->app_secret ?>" />
                            </div>
                        </div>


                        <div class="tab-pane fade" id="socials">
                            <p class="text-muted"><?= $this->language->admin_settings->socials->socials_help ?></p>

                            <?php foreach(require APP_PATH . 'includes/admin_socials.php' AS $key => $value): ?>
                                <div class="form-group">
                                    <label><i class="<?= $value['icon'] ?> fa-fw fa-sm mr-1 text-muted"></i> <?= $value['name'] ?></label>
                                    <input type="text" name="socials_<?= $key ?>" class="form-control form-control-lg" value="<?= $this->settings->socials->{$key} ?>" />
                                </div>
                            <?php endforeach ?>
                        </div>


                        <div class="tab-pane fade" id="smtp">

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->smtp->host ?></label>
                                <input type="text" name="smtp_host" class="form-control form-control-lg" value="<?= $this->settings->smtp->host ?>" />
                                <small class="form-text text-muted"><?= $this->language->admin_settings->smtp->host_help ?></small>
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->smtp->from ?></label>
                                <input type="text" name="smtp_from" class="form-control form-control-lg" value="<?= $this->settings->smtp->from ?>" />
                                <small class="form-text text-muted"><?= $this->language->admin_settings->smtp->from_help ?></small>
                            </div>

                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->smtp->encryption ?></label>
                                        <select name="smtp_encryption" class="form-control form-control-lg">
                                            <option value="0" <?= $this->settings->smtp->encryption == '0' ? 'selected' : null ?>>None</option>
                                            <option value="ssl" <?= $this->settings->smtp->encryption == 'ssl' ? 'selected' : null ?>>SSL</option>
                                            <option value="tls" <?= $this->settings->smtp->encryption == 'tls' ? 'selected' : null ?>>TLS</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-9">
                                    <div class="form-group">
                                        <label><?= $this->language->admin_settings->smtp->port ?></label>
                                        <input type="text" name="smtp_port" class="form-control form-control-lg" value="<?= $this->settings->smtp->port ?>" />
                                    </div>
                                </div>
                            </div>

                            <div class="form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" name="smtp_auth" type="checkbox" value="" <?= $this->settings->smtp->auth ? 'checked' : null ?>>
                                    <?= $this->language->admin_settings->smtp->auth ?>
                                </label>
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->smtp->username ?></label>
                                <input type="text" name="smtp_username" class="form-control form-control-lg" value="<?= $this->settings->smtp->username ?>" <?= ($this->settings->smtp->auth) ? null : 'disabled' ?>/>
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->smtp->password ?></label>
                                <input type="password" name="smtp_password" class="form-control form-control-lg" value="<?= $this->settings->smtp->password ?>" <?= ($this->settings->smtp->auth) ? null : 'disabled' ?>/>
                            </div>

                            <div class="">
                                <a href="admin/settings/testemail<?= \Altum\Middlewares\Csrf::get_url_query() ?>" class="btn btn-info"><?= $this->language->admin_settings->button->test_email ?></a>
                                <small class="form-text text-muted"><?= $this->language->admin_settings->button->test_email_help ?></small>
                            </div>

                        </div>


                        <div class="tab-pane fade" id="custom">
                            <div class="form-group">
                                <label><i class="fab fa-fw fa-sm fa-js text-muted mr-1"></i> <?= $this->language->admin_settings->custom->head_js ?></label>
                                <textarea class="form-control form-control-lg" name="custom_head_js"><?= $this->settings->custom->head_js ?></textarea>
                                <small class="text-muted"><?= $this->language->admin_settings->custom->head_js_help ?></small>
                            </div>

                            <div class="form-group">
                                <label><i class="fab fa-fw fa-sm fa-css3 text-muted mr-1"></i> <?= $this->language->admin_settings->custom->head_css ?></label>
                                <textarea class="form-control form-control-lg" name="custom_head_css"><?= $this->settings->custom->head_css ?></textarea>
                                <small class="text-muted"><?= $this->language->admin_settings->custom->head_css_help ?></small>
                            </div>
                        </div>


                        <div class="tab-pane fade" id="email_notifications">

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->email_notifications->emails ?></label>
                                <textarea class="form-control form-control-lg" name="email_notifications_emails" rows="5"><?= $this->settings->email_notifications->emails ?></textarea>
                                <small class="form-text text-muted"><?= $this->language->admin_settings->email_notifications->emails_help ?></small>
                            </div>

                            <div class="form-check">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input" name="email_notifications_new_user" <?= $this->settings->email_notifications->new_user ? 'checked' : null?>>
                                    <?= $this->language->admin_settings->email_notifications->new_user ?>
                                </label>

                                <small class="form-text text-muted"><?= $this->language->admin_settings->email_notifications->new_user_help ?></small>
                            </div>

                            <div class="form-check">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input" name="email_notifications_new_payment" <?= $this->settings->email_notifications->new_payment ? 'checked' : null?>>
                                    <?= $this->language->admin_settings->email_notifications->new_payment ?>
                                </label>

                                <small class="form-text text-muted"><?= $this->language->admin_settings->email_notifications->new_payment_help ?></small>
                            </div>

                        </div>

                        <div class="tab-pane fade" id="cron">
                            <div class="form-group">
                                <label><?= $this->language->admin_settings->cron->url ?></label>
                                <input type="text" class="form-control form-control-lg" value="<?= url('cron?key=' . $this->settings->cron->key) ?>" readonly="readonly" />
                                <small class="form-text text-muted"><?= $this->language->admin_settings->cron->url_help ?></small>
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->cron->reset_date ?></label>
                                <input type="text" class="form-control disabled" value="<?= $this->settings->cron->reset_date ?>" readonly="readonly" />
                            </div>
                        </div>

                        <div class="tab-pane fade" id="license">
                            <div class="form-group">
                                <label><?= $this->language->admin_settings->license->license ?></label>
                                <input type="text" class="form-control disabled" name="license_license" value="<?= $this->settings->license->license ?>" readonly="readonly" />
                                <small class="form-text text-muted"><?= $this->language->admin_settings->license->license_help ?></small>
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->license->type ?></label>
                                <input type="text" class="form-control disabled" name="license_type" value="<?= $this->settings->license->type ?>" readonly="readonly" />
                            </div>

                            <div class="form-group">
                                <label><?= $this->language->admin_settings->license->new_license ?></label>
                                <input type="text" class="form-control form-control-lg" name="license_new_license" value="" />
                                <small class="form-text text-muted"><?= $this->language->admin_settings->license->new_license_help ?></small>
                            </div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" name="submit" class="btn btn-primary"><?= $this->language->global->update ?></button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>


<?php ob_start() ?>
<script>
    $('input[name="smtp_auth"]').on('change', (event) => {

        if($(event.currentTarget).is(':checked')) {
            $('input[name="smtp_username"],input[name="smtp_password"]').removeAttr('disabled');
        } else {
            $('input[name="smtp_username"],input[name="smtp_password"]').attr('disabled', 'true');
        }

    });
</script>
<?php \Altum\Event::add_content(ob_get_clean(), 'javascript') ?>
