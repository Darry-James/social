<?php defined('ALTUMCODE') || die() ?>








<div class="container-fluid no-gutters">
        <div class="d-flex">
            <div class="sidebar">
                <nav class="navbar flex-column sidebar-contents">
                    <div class="navbar-collapse">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-item ">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="flaticon-megaphone icons nav-icon"></span>
                                   My plan
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           <!--  <li class="nav-item active">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                             <li class="nav-item">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Package
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-payments">
                                    <span class="fa fa-fw fa fa-dollar-sign icons nav-icon"></span>
                                    Payments
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           
                           <li class="nav-item">
                                <a class="nav-link" href="logout">
                                    <span class="fa fa-fw fa fa-sign-out-alt icons nav-icon"></span>
                                    Logout
                                </a>
                            </li> -->

                            <li class="nav-item mb-0">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>
                            <ul class="nav nav-item settings-sub-nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/tutorials/">Tutorials</a>
                                </li>
                                <!-- <li class="nav-item">
                                    <a class="nav-link" href="#">Support</a>
                                </li> -->
                                <li class="nav-item active">
                                    <a class="nav-link" href="account-payments">Billing</a>
                                </li>
                                
                            </ul>

                            <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/bonuses/">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Bonuses
                                     </a>
                                </li>

                            <li class="nav-item">
                                <a class="nav-link" href="https://patrienickhelp.freshdesk.com/support/home">
                                    <span class="flaticon-information icons nav-icon"></span>
                                    Knowledge Base
                                </a>
                            </li>


                        </ul>


                    </div>
               <div>
                        <a class="btn" href="logout">
                            <img class="logout" src="<?= SITE_URL . ASSETS_URL_PATH . 'logout.svg' ?>" alt="log out">
                        </a>
                    </div>
                </nav>
            </div>
            <div class="container-fluid flex-grow-1">
                <div class="d-flex justify-content-between header-wrap">
                    <div class="user-greeting-wrap">
                        <div class="user-greeting">
                            
                            <span class="user-name"></span>
                        </div>
                        <div class="more-info">
                        <h6></h6><br> 


                        </div>

                   
                        

                        </div>




                    <div class="d-flex section-right">
                        <div class="guide-btn-wrap">
                            <a name="btn-help-desk" id="btn-help-desk" class="btn btn-help-desk" href="https://patrienickhelp.freshdesk.com/support/tickets/new"
                                role="button">HELP DESK</a>
                            <a name="btn-tour-guide" id="btn-tour-guide" class="btn btn-tour-guide" href="https://engagrmate.com/tutorials/"
                                role="button">TOUR GUIDE</a>
                        </div>
                        <div class="notification-wrap">
                            <span class="flaticon-music-and-multimedia icons notification-icon"></span>
                        </div>
                        <div class="user-icon">
                            <a href="account">
                                <span class="flaticon-user icons user-icon-default">

                                </span>
                            </a>
                        </div>
                    </div>
                </div>






<header class="header pb-0">
    <div class="container">
        <?= $this->views['account_header'] ?>
    </div>
</header>

<?php require THEME_PATH . 'views/partials/ads_header.php' ?>

<section class="container pt-5">

    <?php display_notifications() ?>

    <h2 class="h3"><?= $this->language->account_payments->header ?></h2>
    <p class="text-muted"><?= $this->language->account_payments->subheader ?></p>

    <?php if($data->payments_result->num_rows): ?>
        <div class="table-responsive table-custom-container">
            <table class="table table-custom">
                <thead>
                <tr>
                    <th><?= $this->language->account_payments->payments->nr ?></th>
                    <th><?= $this->language->account_payments->payments->type ?></th>
                    <th></th>
                    <th><?= $this->language->account_payments->payments->package_id ?></th>
                    <th><?= $this->language->account_payments->payments->email ?></th>
                    <th><?= $this->language->account_payments->payments->name ?></th>
                    <th><?= $this->language->account_payments->payments->amount ?></th>
                    <th><?= $this->language->account_payments->payments->date ?></th>
                    <?php if($this->settings->business->invoice_is_enabled): ?>
                    <th></th>
                    <?php endif ?>
                </tr>
                </thead>
                <tbody>

                <?php $nr = 1; while($row = $data->payments_result->fetch_object()): ?>

                    <?php
                    switch($row->processor) {
                        case 'STRIPE':
                            $row->processor = '<span data-toggle="tooltip" title="' . $this->language->admin_payments->table->stripe .'"><i class="fab fa-fw fa-fw fa-stripe icon-stripe"></i></span>';
                            break;

                        case 'PAYPAL':
                            $row->processor = '<span data-toggle="tooltip" title="' . $this->language->admin_payments->table->paypal .'"><i class="fab fa-fw fa-fw fa-paypal icon-paypal"></i></span>';
                            break;
                    }
                    ?>

                    <tr>
                        <td class="text-muted"><?= $nr++ ?></td>
                        <td><?= $row->type == 'ONE-TIME' ? '<span data-toggle="tooltip" title="' . $row->type . '"><i class="fa fa-fw fa-hand-holding-usd"></i></span>' : '<span data-toggle="tooltip" title="' . $row->type . '"><i class="fa fa-fw fa-sync-alt"></i></span>' ?></td>
                        <td><?= $row->processor ?></td>
                        <td><?= $row->package_name ?></td>
                        <td><?= $row->email ?></td>
                        <td><?= $row->name ?></td>
                        <td><span class="text-success"><?= $row->amount ?></span> <?= $row->currency ?></td>
                        <td class="text-muted"><span data-toggle="tooltip" title="<?= \Altum\Date::get($row->date, 1) ?>"><?= \Altum\Date::get($row->date) ?></span></td>
                        <?php if($this->settings->business->invoice_is_enabled): ?>
                        <td>
                            <a href="<?= url('invoice/' . $row->id) ?>">
                                <span data-toggle="tooltip" title="<?= $this->language->account_payments->payments->invoice ?>"><i class="fa fa-fw fa-file-invoice"></i></span>
                            </a>
                        </td>
                        <?php endif ?>
                    </tr>
                <?php endwhile ?>

                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="text-muted"><?= $this->language->account_payments->info_message->no_payments ?></p>
    <?php endif ?>
</section>
