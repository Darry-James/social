<?php defined('ALTUMCODE') || die() ?>




    <div class="container-fluid no-gutters">
        <div class="d-flex">
            <div class="sidebar">
                

               <nav class="navbar flex-column sidebar-contents">
                    <div class="navbar-collapse">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-item active">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="flaticon-megaphone icons nav-icon"></span>
                                   My plan
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           <!--  <li class="nav-item active">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                             <li class="nav-item">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Package
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-payments">
                                    <span class="fa fa-fw fa fa-dollar-sign icons nav-icon"></span>
                                    Payments
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           
                           <li class="nav-item">
                                <a class="nav-link" href="logout">
                                    <span class="fa fa-fw fa fa-sign-out-alt icons nav-icon"></span>
                                    Logout
                                </a>
                            </li> -->

                            <li class="nav-item mb-0">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>
                            <ul class="nav nav-item settings-sub-nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/tutorials/">Tutorials</a>
                                </li>
                                <!-- <li class="nav-item">
                                    <a class="nav-link" href="#">Support</a>
                                </li> -->
                                <li class="nav-item">
                                    <a class="nav-link" href="account-payments">Billing</a>
                                </li>
                                
                            </ul>

                            <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/bonuses/">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Bonuses
                                     </a>
                                </li>

                            <li class="nav-item">
                                <a class="nav-link" href="https://patrienickhelp.freshdesk.com/support/home">
                                    <span class="flaticon-information icons nav-icon"></span>
                                    Knowledge Base
                                </a>
                            </li>


                        </ul>


                    </div>
               <div>
                        <a class="btn" href="logout">
                            <img class="logout" src="<?= SITE_URL . ASSETS_URL_PATH . 'logout.svg' ?>" alt="log out">
                        </a>
                    </div>
                </nav>

            </div>
            <div class="container-fluid flex-grow-1">
                <!-- <div class="d-flex justify-content-between header-wrap">
                    <div class="user-greeting-wrap">
                        <div class="user-greeting">
                            Welcome,
                            <span class="user-name">Ejem Austine O.</span>
                        </div>
                        <div class="more-info">
                            To get started, kindly refer to our quick checklist
                            <span class="flaticon-interface-1 icons checklist-icon"></span>
                        </div>
                    </div>
                    <div class="d-flex section-right">
                        <div class="guide-btn-wrap">
                            <a name="btn-help-desk" id="btn-help-desk" class="btn btn-help-desk" href="#"
                                role="button">HELP DESK</a>
                            <a name="btn-tour-guide" id="btn-tour-guide" class="btn btn-tour-guide" href="#"
                                role="button">TOUR GUIDE</a>
                        </div>
                        <div class="notification-wrap">
                            <span class="flaticon-music-and-multimedia icons notification-icon"></span>
                        </div>
                        <user-image-icon></user-image-icon>
                    </div>
                </div> -->
                <div class="d-flex flex-column align-items-end">
                    <div class="d-flex justify-content-between header-wrap">
                        <div class="title-wrap">
                            


                  

<?php require THEME_PATH . 'views/partials/ads_header.php' ?>


                    </div>
                        <div class="d-flex section-right">
                            <div class="guide-btn-wrap">
                                <a name="btn-help-desk" id="btn-help-desk" class="btn btn-help-desk" href="https://patrienickhelp.freshdesk.com/support/tickets/new"
                                    role="button">HELP DESK</a>
                                <a name="btn-tour-guide" id="btn-tour-guide" class="btn btn-tour-guide" href="https://engagrmate.com/tutorials/"
                                    role="button">TOUR GUIDE</a>
                            </div>
                            <div class="notification-wrap">
                                <span class="flaticon-music-and-multimedia icons notification-icon"></span>
                            </div>
                            <div class="user-icon">
                                <a href="dashboard">
                                    <span class="flaticon-user icons user-icon-default">

                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>

 

        </div>




<input type="hidden" id="base_controller_url" name="base_controller_url" value="<?= url('campaign/' . $data->campaign->campaign_id) ?>" />

<header class="header-none">
    <div class="container">
        <h1 class="h2 mr-3">New Notification</h1>

        <!-- <div class="d-flex align-items-center text-muted mr-3">
            <img src="https://www.google.com/s2/favicons?domain=<?= $data->campaign->domain ?>" class="img-fluid mr-1" />

            <a href="<?= url('campaign/' . $data->campaign->campaign_id) ?>">
                <?= $data->campaign->domain ?>
            </a> -->
        </div>
    
</header>

<?php require THEME_PATH . 'views/partials/ads_header.php' ?>

<section class="container">

    <?php display_notifications() ?>


    <!-- <div class="col-6">
    <div class="popup-wrap h-100">
        <div id="notification_preview">
            <img class="img-fluid top-design" src="<?= SITE_URL . ASSETS_URL_PATH . 'shape-top.png' ?>" alt="top-design">
            <img class="img-fluid bottom-design" src="<?= SITE_URL . ASSETS_URL_PATH . 'shape-bottom.png' ?>" alt="top-design">
        </div>
    </div>
</div> 
 -->


  <div class="my-5 mb-lg-0 d-flex flex-column flex-md-row justify-content-center align-items-center">
        <div id="notification_preview" style="
        display: flex;
        align-items: center;
        border: 1px solid #6b60cb; 
        width: auto; 
        background-color: #ffffff;"></div>
    </div>  


<div class="notification-heading">
<h5 class="notification section-title">
    Configure
</h5>
<p class="notification section-title">
    Choose the notification name and type that you want for your new
    notification.
</p>
<div>



    <form name="create_notification" method="post" role="form">
        <input type="hidden" name="token" value="<?= \Altum\Middlewares\Csrf::get() ?>" required="required" />
        <input type="hidden" name="request_type" value="create" />
        <input type="hidden" name="campaign_id" value="<?= $data->campaign->campaign_id ?>" />

        <div class="form-group d-flex align-items-center">
           <label for="notification-name">Name</label>
            <input type="text" class="form-control" name="name" required="required"  placeholder="Name your Notification"/>
        </div>











       <div class="d-flex notification-type-section">
        <div class="step-section">
        <div class="state active">
            <div class="value">
                1
            </div>
            <div class="step-tooltip-outter">
                <div class="step-tooltip">
                    Notification Type
                </div>
            </div>
        </div>
        <div class="state">
            <div class="value">
                2
            </div>
            <div class="line">

            </div>
        </div>
        <div class="state">
            <div class="value">
                3
            </div>
            <div class="line">

            </div>
        </div>
    </div>







        <div class="d-flex notification-types-selection w-100">
            <?php foreach($data->notifications as $notification_type => $notification_config): ?>

                <?php

                /* Check for permission of usage of the notification */
                if(!$this->user->package_settings->enabled_notifications->{$notification_type}) {
                    continue;
                }

                ?>

                <?php $notification = \Altum\Notification::get($notification_type) ?>

                <label class="col-md-6 col-md-6 custom-radio-box mb-3">

                    <input type="radio" name="type" value="<?= $notification_type ?>" class="custom-control-input" required="required">

                   <div class="notification-type-box">
                    <span class="flaticon-push-pin icons notification-pin-icon"></span>
                        <div class="notification-content">

                             <span class="icons notification-info-icon"><i class="<?= $this->language->notification->{strtolower($notification_type)}->icon ?>"></i> </span>
                            <h2 class="notification-type"><?= $this->language->notification->{strtolower($notification_type)}->name ?></h2> 

                           <!--  <h2> <?= $this->language->notification->{strtolower($notification_type)}->description ?>  </h2>


                            <div class="mb-3 text-center">
                                <span class="custom-radio-box-main-icon"><i class="<?= $this->language->notification->{strtolower($notification_type)}->icon ?>"></i></span>
                            </div>

                            <div class="card-title font-weight-bold text-center"><?= $this->language->notification->{strtolower($notification_type)}->name ?></div>

                            <p class="text-muted text-center"><?= $this->language->notification->{strtolower($notification_type)}->description ?></p> -->

                        </div>
                    </div>

                    <div class="preview" style="display: none">
                        <?= preg_replace(['/<form/', '/<\/form>/', '/required=\"required\"/'], ['<div', '</div>', ''], $notification->html) ?>
                    </div>

                </label>

            <?php endforeach ?>
        </div>
    </div>

        <div class="mt-4">
            <button type="submit" name="submit" class="btn btn-primary mr-2">NEXT<!-- <?= $this->language->global->create ?> --></button>
        </div>
    </form>
</section>

<?php ob_start() ?>
<script>
    /* Preview handler */
    $('input[name="type"]').on('change', event => {

        let preview_html = $(event.currentTarget).closest('label').find('.preview').html();
        let type = $(event.currentTarget).val();

        console.log(type);

        $('#notification_preview').hide().html(preview_html).fadeIn();

        if(type.includes('_BAR')) {
            $('#notification_preview').removeClass().addClass('notification-create-preview-bar');
        } else {
            $('#notification_preview').removeClass().addClass('notification-create-preview-normal');
        }
    });

    /* Select a default option */
    $('input[name="type"]:first').attr('checked', true).trigger('change');

    /* Form submission */
    $('form[name="create_notification"]').on('submit', event => {

        $.ajax({
            type: 'POST',
            url: 'notifications-ajax',
            data: $(event.currentTarget).serialize(),
            success: (data) => {
                if (data.status == 'error') {
                    notification_container.html('');

                    display_notifications(data.message, 'error', notification_container);
                }

                else if(data.status == 'success') {

                    /* Fade out refresh */
                    redirect(`notification/${data.details.notification_id}`);

                }
            },
            dataType: 'json'
        });

        event.preventDefault();
    });
</script>
<?php \Altum\Event::add_content(ob_get_clean(), 'javascript') ?>
































              
            </div>

          

        </div>
    </div>

    <!-- <script src="https://unpkg.com/@popperjs/core@2"></script> -->
    <script src="../assets/js/jquery/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="../assets/js/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/js/custom/main.js"></script>
</body>

</html>