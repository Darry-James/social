<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/bootstap/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/css/main.css">
    <title>Login</title>
</head>

<body>

    <div class="container full-height">
        <div class="row main-container full-height">
            <div class="col-6">
                <div class="position-relative">
                    <div class="image-wrap">
                        <!-- <img src="./assets/images/happy-ethnic-woman-sitting-at-table-with-laptop-3769021.jpg"
                            class="img-fluid" alt="happy ethnic woman sitting at table with laptop"> -->
                    </div>
                    <div class="active-user-pop-up-outer users-online-pop">
                        <div class="active-user-pop-up">
                            <span class="icon-close-tool  close-pop"></span>
                            <div class="avatar-icon">
                                <img src="./assets/icons/avatar.svg" class="img-fluid" alt="avatar">
                            </div>
                            <div class="d-flex flex-column">
                                <div>
                                    <div class="active-users">
                                        <div class="checked-icon">
                                        </div>
                                        <span class="value">20</span>
                                    </div>
                                </div>
                                <div class="desc-text">
                                    Active visitors now.
                                </div>
                                <div class="verification-text">
                                    Verified by EngageProof
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="active-user-pop-up-outer flash-sales-pop">
                        <div class="active-user-pop-up flash-sales-pop-up">
                            <span class="icon-close-tool  close-pop"></span>

                            <div class="icon-commerce-and-shopping flash-sales-icon"></div>
                            <div class="d-flex flex-column">
                                <div>
                                    <div class="flash-sale">

                                        FLASH SALE!
                                        <span class="fire-icon"></span>
                                    </div>
                                </div>
                                <div class="desc-text">
                                    Limited sale until tonight, right now!
                                </div>
                                <div class="verification-text">
                                    Verified by EngageProof
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="pop-up red-pop-up">

                    </div>

                    <div class="pop-up purple-pop-up">

                    </div>

                    <div class="icon-commerce-and-shopping flash-sales-icon-pop-up"></div>
                    <div class="active-users online-user-pop-up">
                        <div class="checked-icon">
                        </div>
                        <span class="value">20</span>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="login-form-section-wrap">
                    <div class="logo-section">

                    </div>
                    <form class="login-form" method="post" action="">
                        <h1 class="form-title">
                            Login to Account
                        </h1>
                        <div class="form-group">
                            <label for="username">USERNAME</label>
                            <input id="username" class="form-control engage-form" type="text" name="username">
                        </div>
                        <div class="form-group">
                            <label for="password">PASSWORD</label>
                            <input id="password" class="form-control engage-form" type="password" name="password">
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <button type="button" class="btn btn-engage">LOG ME IN</button>
                            <div class="forgot-password"><a href="#" class="forgot-password-link">Forgot Password</a>
                            </div>
                        </div>
                    </form>

                    <nav class="nav social-media">
                        <a class="nav-link" href="#">
                            <div class="social-icon-wrap">
                                <img src="./assets/icons/facebook.svg" class="img-fluid" alt="facebook logo">
                            </div>
                        </a>
                        <a class="nav-link" href="#">
                            <div class="social-icon-wrap">
                                <img src="./assets/icons/instagram.svg" class="img-fluid" alt="instagram logo">
                            </div>
                        </a>
                        <a class="nav-link" href="#">
                            <div class="social-icon-wrap">
                                <img src="./assets/icons/google.svg" class="img-fluid" alt="google logo">
                            </div>
                        </a>
                    </nav>
                    <span class="icon-commerce-and-shopping percent-icon"></span>
                </div>
            </div>
        </div>
    </div>

    <script src="./assets/js/jquery/jquery-3.5.1.min.js"></script>
    <script src="./assets/js/popper/popper.min.js"></script>
    <script src="./assets/js/bootstrap/bootstrap.min.js"></script>
    <script src="./assets/js/custom/main.js"></script>
</body>

</html>