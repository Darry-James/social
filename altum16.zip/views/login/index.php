<?php defined('ALTUMCODE') || die() ?>

<?php require THEME_PATH . 'views/partials/ads_header.php' ?>




<div class="container full-height">
        <div class="row main-container full-height">
            <div class="col-6">
                <?php display_notifications() ?>
                <div class="position-relative">
                    <div class="image-wrap">
                       
                    </div>
                    <div class="active-user-pop-up-outer users-online-pop">
                        <div class="active-user-pop-up">
                            <span class="icon-close-tool  close-pop"></span>
                            <div class="avatar-icon">
                                <img src="<?= SITE_URL . ASSETS_URL_PATH . 'icons/avatar.svg' ?>" class="img-fluid" alt="avatar">
                            </div>
                            <div class="d-flex flex-column">
                                <div>
                                    <div class="active-users">
                                        <div class="checked-icon">
                                        </div>
                                        <span class="value">2,710</span>
                                    </div>
                                </div>
                                <div class="desc-text">
                                    Active visitors now.
                                </div>
                                <div class="verification-text">
                                    Verified by EngageProof
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="active-user-pop-up-outer flash-sales-pop">
                        <div class="active-user-pop-up flash-sales-pop-up">
                            <span class="icon-close-tool  close-pop"></span>

                            <div class="icon-commerce-and-shopping flash-sales-icon"></div>
                            <div class="d-flex flex-column">
                                <div>
                                    <div class="flash-sale">

                                        FLASH SALE!
                                        <span class="fire-icon"></span>
                                    </div>
                                </div>
                                <div class="desc-text">
                                    Limited sale until tonight, right now!
                                </div>
                                <div class="verification-text">
                                    Verified by EngageProof
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="pop-up red-pop-up">
                        

                    </div>

                    <div class="pop-up purple-pop-up">

                    </div>

                    <div class="icon-commerce-and-shopping flash-sales-icon-pop-up"></div>
                    <div class="active-users online-user-pop-up">
                        <div class="checked-icon">
                        </div>
                        <span class="value">173,<?= nr($data->total_track_notifications) ?>+ Notifications</span>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="login-form-section-wrap">
                    <div class="logo-section" style="margin-top: -10px;"> <a href=""><img src="<?= SITE_URL . ASSETS_URL_PATH . 'logo.png' ?>  " height="50"><span style="font-size: 25px;">Engagrmate</span></a> 

                    </div> <br> <br> <br> <br> 
                    <form class="login-form" method="post" action="" role="form">
                        <h1 class="form-title">
                            Login to Account
                        </h1>  
                        <div class="form-group">
                            <label for="username">EMAIL ADDRESS</label>
                            <input id="email" class="form-control engage-form" type="text" name="email"  required="required">
                        </div>
                        <div class="form-group">
                            <label for="password">PASSWORD</label>
                            <input id="password" class="form-control engage-form" type="password" name="password"  required="required">
                        </div>

                        <?php if($data->login_account && $data->login_account->twofa_secret && $data->login_account->active): ?>
                            <div class="form-group">
                                <label><?= $this->language->login->form->twofa_token ?></label>
                                <input type="text" name="twofa_token" class="form-control form-control-lg" placeholder="<?= $this->language->login->form->twofa_token_placeholder ?>" required="required" autocomplete="off" />
                            </div>
                        <?php endif ?>

                         <div class="form-check">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input" name="rememberme">
                                <small class="text-muted"><?= $this->language->login->form->remember_me ?></small>
                            </label>
                        </div>
                        <br>

                        <div class="d-flex justify-content-between align-items-center">
                            <button type="submit" name="submit" class="btn btn-engage">LOG ME IN</button>
                            
                        </div>  
                       <br>
                        <div class="forgot-password"> 
                                <small><a href="lost-password" class="forgot-password-link"><?= $this->language->login->display->lost_password ?></a> / <a href="resend-activation" class="forgot-password-link" role="button"><?= $this->language->login->display->resend_activation ?></a></small>
                            </div>
                    </form>

                    <nav class="nav social-media">


                         <?php if($this->settings->facebook->is_enabled): ?>

                            <div class="d-flex align-items-center my-3">
                                <div class="line bg-gray-300"></div>
                                <div class="mx-3"><small class=""><?= $this->language->login->form->or ?></small></div>
                                <div class="line bg-gray-300"></div>
                            </div>

                            <div class="row">
                                <div class="col-sm mt-1">
                                    <a href="<?= $data->facebook_login_url ?>" class="btn btn-light btn-block text-gray-600">
                                        <div class="social-icon-wrap">
                                <img src="<?= SITE_URL . ASSETS_URL_PATH . 'icons/facebook.svg' ?>" class="img-fluid" alt="facebook logo">
                            </div>

                                    </a>
                                </div>
                            </div>
                        <?php endif ?>



                       <!--  <a class="nav-link" href="#">
                            <div class="social-icon-wrap">
                                <img src="<?= SITE_URL . ASSETS_URL_PATH . 'icons/facebook.svg' ?>" class="img-fluid" alt="facebook logo">
                            </div>
                        </a> -->




                     <!--    <a class="nav-link" href="#">
                            <div class="social-icon-wrap">
                                <img src="<?= SITE_URL . ASSETS_URL_PATH . 'icons/instagram.svg' ?>" class="img-fluid" alt="instagram logo">
                            </div>
                        </a>
                        <a class="nav-link" href="#">
                            <div class="social-icon-wrap">
                                <img src="<?= SITE_URL . ASSETS_URL_PATH . 'icons/google.svg' ?>" class="img-fluid" alt="google logo">
                            </div>
                        </a> -->
                    </nav>
                    <!-- <?php if($this->settings->register_is_enabled): ?>
                <div class="text-center mt-4">
                    <?= sprintf($this->language->login->display->register, '<a href="' . url('register') . '" class="font-weight-bold">' . $this->language->login->display->register_help . '</a>') ?></a>
                </div>
            <?php endif ?> -->


                    <span class="icon-commerce-and-shopping percent-icon"></span>
                </div>
            </div>
        </div>
    </div>












