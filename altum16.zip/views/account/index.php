<?php defined('ALTUMCODE') || die() ?>







 <div class="container-fluid no-gutters">
        <div class="d-flex">
            <div class="sidebar">
                <nav class="navbar flex-column sidebar-contents">
                    <div class="navbar-collapse">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-item ">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="flaticon-megaphone icons nav-icon"></span>
                                   My plan
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           <!--  <li class="nav-item active">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                             <li class="nav-item">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Package
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-payments">
                                    <span class="fa fa-fw fa fa-dollar-sign icons nav-icon"></span>
                                    Payments
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           
                           <li class="nav-item">
                                <a class="nav-link" href="logout">
                                    <span class="fa fa-fw fa fa-sign-out-alt icons nav-icon"></span>
                                    Logout
                                </a>
                            </li> -->

                            <li class="nav-item active mb-0">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>
                            <ul class="nav nav-item settings-sub-nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/tutorials/">Tutorials</a>
                                </li>
                                <!-- <li class="nav-item">
                                    <a class="nav-link" href="#">Support</a>
                                </li> -->
                                <li class="nav-item">
                                    <a class="nav-link" href="account-payments">Billing</a>
                                </li>
                                
                            </ul>

                            <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/bonuses/">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Bonuses
                                     </a>
                                </li>

                            <li class="nav-item">
                                <a class="nav-link" href="https://patrienickhelp.freshdesk.com/support/home">
                                    <span class="flaticon-information icons nav-icon"></span>
                                    Knowledge Base
                                </a>
                            </li>


                        </ul>


                    </div>
               <div>
                        <a class="btn" href="logout">
                            <img class="logout" src="<?= SITE_URL . ASSETS_URL_PATH . 'logout.svg' ?>" alt="log out">
                        </a>
                    </div>
                </nav>
            </div>
            <div class="container-fluid flex-grow-1">
                <div class="d-flex justify-content-between header-wrap">
                    <div class="user-greeting-wrap">
                        <div class="user-greeting">
                            
                            <span class="user-name"></span>
                        </div>
                        <div class="more-info">
                        <h6></h6><br> 


                        </div>

                   
                        

                        </div>




                    <div class="d-flex section-right">
                        <div class="guide-btn-wrap">
                            <a name="btn-help-desk" id="btn-help-desk" class="btn btn-help-desk" href="https://patrienickhelp.freshdesk.com/support/tickets/new"
                                role="button">HELP DESK</a>
                            <a name="btn-tour-guide" id="btn-tour-guide" class="btn btn-tour-guide" href="https://engagrmate.com/tutorials/"
                                role="button">TOUR GUIDE</a>
                        </div>
                        <div class="notification-wrap">
                            <span class="flaticon-music-and-multimedia icons notification-icon"></span>
                        </div>
                        <div class="user-icon">
                            <a href="account">
                                <span class="flaticon-user icons user-icon-default">

                                </span>
                            </a>
                        </div>
                    </div>
                </div>









<header class="header pb-0">
    <div class="container">
        <?= $this->views['account_header'] ?>
    </div>
</header>

<?php require THEME_PATH . 'views/partials/ads_header.php' ?>

<section class="container pt-5">

    <?php display_notifications() ?>

    <form action="" method="post" role="form">
        <input type="hidden" name="token" value="<?= \Altum\Middlewares\Csrf::get() ?>" />

        <div class="row">
            <div class="col-12 col-md-4">
                <h2 class="h3"><?= $this->language->account->settings->header ?></h2>
                <p class="text-muted"><?= $this->language->account->settings->subheader ?></p>
            </div>

            <div class="col">
                <div class="form-group">
                    <label for="name"><?= $this->language->account->settings->name ?></label>
                    <input type="text" id="name" name="name" class="form-control" value="<?= $this->user->name ?>" />
                </div>

                <div class="form-group">
                    <label for="email"><?= $this->language->account->settings->email ?></label>
                    <input type="text" id="email" name="email" class="form-control" value="<?= $this->user->email ?>" />
                </div>

                <div class="form-group">
                    <label for="timezone"><?= $this->language->account->settings->timezone ?></label>
                    <select id="timezone" name="timezone" class="form-control">
                        <?php foreach(DateTimeZone::listIdentifiers() as $timezone) echo '<option value="' . $timezone . '" ' . ($this->user->timezone == $timezone ? 'selected' : null) . '>' . $timezone . '</option>' ?>
                    </select>
                    <small class="text-muted"><?= $this->language->account->settings->timezone_help ?></small>
                </div>
            </div>
        </div>

        <div class="margin-top-3"></div>

        <div class="row">
            <div class="col-12 col-md-4">
                <h2 class="h3"><?= $this->language->account->twofa->header ?></h2>
                <p class="text-muted"><?= $this->language->account->twofa->subheader ?></p>
            </div>

            <div class="col">
                <div class="form-group">
                    <label><?= $this->language->account->twofa->is_enabled ?></label>

                    <select name="twofa_is_enabled" class="form-control">
                        <option value="1" <?= $this->user->twofa_secret ? 'selected' : null ?>><?= $this->language->global->yes ?></option>
                        <option value="0" <?= !$this->user->twofa_secret ? 'selected' : null ?>><?= $this->language->global->no ?></option>
                    </select>
                </div>

                <div id="twofa_container">
                    <?php if(!$this->user->twofa_secret): ?>
                        <div class="form-group">
                            <label><?= $this->language->account->twofa->qr ?></label>
                            <p class="text-muted"><?= $this->language->account->twofa->qr_help ?></p>

                            <div class="d-flex flex-column flex-md-row align-items-center">
                                <div class="mb-3 mb-md-0 mr-md-5">
                                    <img src="<?= $data->twofa_image ?>" alt="<?= $this->language->account->twofa->qr ?>" />
                                </div>

                                <div>
                                    <label><?= $this->language->account->twofa->secret ?></label>
                                    <p class="text-muted"><?= $this->language->account->twofa->secret_help ?></p>

                                    <p class="h5"><?= $data->twofa_secret ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="twofa_token"><?= $this->language->account->twofa->verify ?></label>
                            <p class="text-muted"><?= $this->language->account->twofa->verify_help ?></p>
                            <input type="text" id="twofa_token" name="twofa_token" class="form-control" value="" autocomplete="off" />
                        </div>
                    <?php endif ?>
                </div>
            </div>
        </div>

        <div class="margin-top-3"></div>

        <div class="row">
            <div class="col-12 col-md-4">
                <h2 class="h3"><?= $this->language->account->change_password->header ?></h2>
                <p class="text-muted"><?= $this->language->account->change_password->subheader ?></p>
            </div>

            <div class="col">
                <div class="form-group">
                    <label for="old_password"><?= $this->language->account->change_password->current_password ?></label>
                    <input type="password" id="old_password" name="old_password" class="form-control" />
                </div>

                <div class="form-group">
                    <label for="new_password"><?= $this->language->account->change_password->new_password ?></label>
                    <input type="password" id="new_password" name="new_password" class="form-control" />
                </div>

                <div class="form-group">
                    <label for="repeat_password"><?= $this->language->account->change_password->repeat_password ?></label>
                    <input type="password" id="repeat_password" name="repeat_password" class="form-control" />
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12 col-md-4"></div>

            <div class="col">
                <button type="submit" name="submit" class="btn btn-primary"><?= $this->language->global->update ?></button>
            </div>
        </div>
    </form>

    <div class="margin-top-6 d-flex justify-content-between align-items-center">
        <div>
            <h2 class="h3"><?= $this->language->account->delete->header ?></h2>
            <p class="text-muted"><?= $this->language->account->delete->subheader ?></p>
        </div>

        <a href="<?= url('account/delete' . \Altum\Middlewares\Csrf::get_url_query()) ?>" class="btn btn-secondary" data-confirm="<?= $this->language->account->delete->confirm_message ?>"><?= $this->language->global->delete ?></a>
    </div>

</section>

<?php if(!$this->user->twofa_secret): ?>
    <?php ob_start() ?>
    <script>
        let twofa = () => {
            let is_enabled = parseInt($('select[name="twofa_is_enabled"]').find(':selected').val());

            if(is_enabled) {
                $('#twofa_container').show();
            } else {
                $('#twofa_container').hide();

            }
        };

        twofa();

        $('select[name="twofa_is_enabled"]').on('change', twofa);
    </script>
    <?php \Altum\Event::add_content(ob_get_clean(), 'javascript') ?>
<?php endif ?>
