<?php defined('ALTUMCODE') || die() ?>












<div class="container-fluid no-gutters">
        <div class="d-flex">
            <div class="sidebar">
                <nav class="navbar flex-column sidebar-contents">
                    <div class="navbar-collapse">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-item ">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="flaticon-megaphone icons nav-icon"></span>
                                   My plan
                                </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           <!--  <li class="nav-item active">
                                <a class="nav-link" href="dashboard">
                                    <span class="flaticon-dashboard icons nav-icon"></span>
                                    Dashboard
                                </a>
                            </li>

                             <li class="nav-item">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-package">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Package
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-payments">
                                    <span class="fa fa-fw fa fa-dollar-sign icons nav-icon"></span>
                                    Payments
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="account-logs">
                                    <span class="flaticon-line-chart icons nav-icon"></span>
                                    Logs
                                </a>
                            </li>
                           
                           <li class="nav-item">
                                <a class="nav-link" href="logout">
                                    <span class="fa fa-fw fa fa-sign-out-alt icons nav-icon"></span>
                                    Logout
                                </a>
                            </li> -->

                            <li class="nav-item mb-0">
                                <a class="nav-link" href="account">
                                    <span class="flaticon-settings icons nav-icon"></span>
                                    Settings
                                </a>
                            </li>
                            <ul class="nav nav-item settings-sub-nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/tutorials/">Tutorials</a>
                                </li>
                                <!-- <li class="nav-item">
                                    <a class="nav-link" href="#">Support</a>
                                </li> -->
                                <li class="nav-item">
                                    <a class="nav-link" href="account-payments">Billing</a>
                                </li>
                                
                            </ul>

                            <li class="nav-item">
                                    <a class="nav-link" href="https://engagrmate.com/bonuses/">
                                    <span class="fa fa-fw fa fa-box-open icons nav-icon"></span>
                                    Bonuses
                                     </a>
                                </li>

                            <li class="nav-item">
                                <a class="nav-link" href="https://patrienickhelp.freshdesk.com/support/home">
                                    <span class="flaticon-information icons nav-icon"></span>
                                    Knowledge Base
                                </a>
                            </li>


                        </ul>


                    </div>
               <div>
                        <a class="btn" href="logout">
                            <img class="logout" src="<?= SITE_URL . ASSETS_URL_PATH . 'logout.svg' ?>" alt="log out">
                        </a>
                    </div>
                </nav>
            </div>
            <div class="container-fluid flex-grow-1">
                <div class="d-flex justify-content-between header-wrap">
                    <div class="user-greeting-wrap">
                        <div class="user-greeting">
                            
                            <span class="user-name"></span>
                        </div>
                        <div class="more-info">
                        <h6></h6><br> 


                        </div>

                   
                        

                        </div>




                    <div class="d-flex section-right">
                        <div class="guide-btn-wrap">
                            <a name="btn-help-desk" id="btn-help-desk" class="btn btn-help-desk" href="https://patrienickhelp.freshdesk.com/support/tickets/new"
                                role="button">HELP DESK</a>
                            <a name="btn-tour-guide" id="btn-tour-guide" class="btn btn-tour-guide" href="https://engagrmate.com/tutorials/"
                                role="button">TOUR GUIDE</a>
                        </div>
                        <div class="notification-wrap">
                            <span class="flaticon-music-and-multimedia icons notification-icon"></span>
                        </div>
                        <div class="user-icon">
                            <a href="account">
                                <span class="flaticon-user icons user-icon-default">

                                </span>
                            </a>
                        </div>
                    </div>
                </div>










<header class="header pb-0">
    <div class="container">
        <?= $this->views['account_header'] ?>
    </div>
</header>

<?php require THEME_PATH . 'views/partials/ads_header.php' ?>

<section class="container pt-5">

    <?php display_notifications() ?>

    <h2 class="h3"><?= $this->language->account_logs->header ?></h2>
    <p class="text-muted"><?= $this->language->account_logs->subheader ?></p>

    <?php if($data->logs_result->num_rows): ?>
        <div class="table-responsive table-custom-container">
            <table class="table table-custom">
                <thead>
                <tr>
                    <th><?= $this->language->account_logs->logs->type ?></th>
                    <th><?= $this->language->account_logs->logs->ip ?></th>
                    <th><?= $this->language->account_logs->logs->date ?></th>
                </tr>
                </thead>
                <tbody>

                <?php $nr = 1; while($row = $data->logs_result->fetch_object()): ?>
                    <tr>
                        <td><?= $row->type ?></td>
                        <td><?= $row->ip ?></td>
                        <td class="text-muted"><?= \Altum\Date::get($row->date, 1) ?></td>
                    </tr>
                <?php endwhile ?>

                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="text-muted"><?= $this->language->account_logs->info_message->no_logs ?></p>
    <?php endif ?>

</section>
